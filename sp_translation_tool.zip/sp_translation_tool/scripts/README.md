# EMTP to Simscape Conversion & Validation

## Workflow

### 1. Convert EMTP circuit to JSON

```bash
python parsers/emtp_to_json.py data/EMTP/Circ_AC_R_1
```

Produces `Circuit150301.json` with topology, parameters, and coordinates.

### 2. Build Simscape model and run simulation (MATLAB)

Uses **Simscape Electrical > Specialized Power Systems** (SPS) with powergui.
Tested on MATLAB R2024b. Block paths use `spsXxxLib/Block Name` format.
To find a block path: add it manually, select it, run `get_param(gcb, 'ReferenceBlock')`.

In MATLAB:

```matlab
addpath('scripts');
[json_path, csv_path] = json_to_simscape('data/EMTP/Circ_AC_R_1/Circuit150301.json');
```

This will:
- Create `Circuit150301.slx` (SPS model with powergui)
- Run the simulation
- Export results to `Circuit150301_simscape.csv`

### 3. Validate results (Python)

```bash
pip install -r requirements.txt
python scripts/validate_simulation.py data/EMTP/Circ_AC_R_1
```

Compares EMTP (`res150301.csv`) and Simscape (`Circuit150301_simscape.csv`) voltage waveforms using RMSE. Pass if RMSE < tolerance (default 0.01 V).

### Prerequisites

- **MATLAB** with Simulink and Simscape Electrical
- **Python 3.8+** with numpy, scipy (for validation)
