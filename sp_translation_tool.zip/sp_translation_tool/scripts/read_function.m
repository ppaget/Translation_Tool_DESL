% run_translate_Circuit150301.m
% Appel de translate_to_mat_file pour Circuit150301.mda
% Detecte : 5 colonnes, float64, format Fortran, 32002 lignes

filename   = 'EMTP\Circuit150301_pj\Circuit150301.mda';  % <-- adapter le chemin
ncols      = 5;
precision  = 'float64';
fileformat = 'fortran';

global DatafromFile
DatafromFile.active            = false;
DatafromFile.Waitbar           = false;
DatafromFile.use_mat_extension = true;

fidbin = fopen(filename, 'rb');
if fidbin == -1, error('Impossible d''ouvrir : %s', filename); end

mymfilename = mfilename('fullpath');

[nlines, mat_file_name] = translate_to_mat_file( ...
    mymfilename, filename, fidbin, ncols, precision, fileformat);

fprintf('Lignes lues  : %d\n', nlines);
fprintf('Fichier .mat : %s\n', mat_file_name);

load(mat_file_name);
fprintf('Taille amatrix : %d x %d\n', size(amatrix,1), size(amatrix,2));

% Tracé des 5 colonnes
figure;
for k = 1:5
    subplot(5,1,k);
    plot(amatrix(:,k));
    title(sprintf('Colonne %d', k));
    grid on;
end
sgtitle('Circuit150301');