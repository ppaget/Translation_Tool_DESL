% json_to_simscape.m
% Builds a Simscape Electrical Specialized Power Systems model from circuit JSON.
% Uses powerlib blocks (Simscape > Electrical > Specialized Power Systems).
% Requires powergui. Tested on MATLAB R2024b.
%
% Usage:
%   json_to_simscape('data/EMTP/Circ_AC_R_1/Circuit150301.json')
%   json_to_simscape()  % uses default path
%
% Output: Creates model .slx, runs sim, writes Circuit150301_simscape.csv

function [model_path, csv_path] = json_to_simscape(json_path)
    if nargin < 1
        json_path = fullfile(fileparts(mfilename('fullpath')), '..', ...
            'data', 'EMTP', 'Circ_AC_R_1', 'Circuit150301.json');
    end
    json_path = char(json_path);

    if ~isfile(json_path)
        error('JSON file not found: %s', json_path);
    end

    % Load circuit definition
    txt = fileread(json_path);
    circuit = jsondecode(txt);

    model_name = circuit.model_name;
    solver = circuit.solver_settings;
    components = circuit.components;
    nodes = circuit.nodes;

    % Create new model (close if exists)
    if bdIsLoaded(model_name)
        close_system(model_name, 0);
    end
    new_system(model_name);
    open_system(model_name);

    % Block library paths (SPS). To find a path: add block manually, select it, run:
    %   get_param(gcb, 'ReferenceBlock')
    % Then add to this struct. Format: 'spsXxxLib/Block Name'
    lib = struct();
    lib.powergui = 'powerlib/powergui';
    lib.ground = 'spsGroundLib/Ground';
    lib.ac_voltage = 'spsACVoltageSourceLib/AC Voltage Source';
    lib.dc_voltage = 'spsDCVoltageSourceLib/DC Voltage Source';
    lib.series_rlc = 'spsSeriesRLCBranchLib/Series RLC Branch';
    lib.voltage_meas = 'spsVoltageMeasurementLib/Voltage Measurement';

    % Add powergui (required for SPS - must be named 'powergui')
    add_block(lib.powergui, [model_name '/powergui']);
    set_param([model_name '/powergui'], 'Position', [50 50 120 100]);

    % Add Ground
    add_block(lib.ground, [model_name '/GND']);
    set_param([model_name '/GND'], 'Position', [200 300 230 330]);

    % Scale factor for block positions (Simulink pixels)
    scale = 80;
    base_x = 150;
    base_y = 150;

    % Map: node -> list of {block, port_name}
    node_blocks = containers.Map('KeyType', 'char', 'ValueType', 'any');
    for i = 1:length(nodes)
        node_blocks(nodes{i}) = {};
    end

    % Add components and track node connections
    for k = 1:length(components)
        comp = components(k);
        cid = comp.id;
        ctype = comp.type;
        params = comp.parameters;
        conn = comp.connections;

        pos = [base_x + (k-1)*scale*2, base_y, base_x + (k-1)*scale*2 + 80, base_y + 50];
        if isfield(comp, 'position')
            pos = [base_x + comp.position.x*scale, base_y + comp.position.y*scale, ...
                   base_x + comp.position.x*scale + 80, base_y + comp.position.y*scale + 50];
        end

        switch ctype
            case 'Resistor'
                add_block(lib.series_rlc, [model_name '/' cid]);
                set_param([model_name '/' cid], 'Position', pos);
                set_param([model_name '/' cid], 'BranchType', 'R');
                set_param([model_name '/' cid], 'Resistance', num2str(params.resistance));
                conn1 = conn.terminal_1;
                conn2 = conn.terminal_2;
                node_blocks = append_node(node_blocks, conn1, struct('block', cid, 'port', 1));
                node_blocks = append_node(node_blocks, conn2, struct('block', cid, 'port', 2));

            case 'VoltageSourceAC'
                add_block(lib.ac_voltage, [model_name '/' cid]);
                set_param([model_name '/' cid], 'Position', pos);
                % SPS AC Voltage Source uses peak amplitude; JSON has RMS
                v_peak = params.voltage_rms * sqrt(2);
                set_param([model_name '/' cid], 'Amplitude', sprintf('%g', v_peak));
                set_param([model_name '/' cid], 'Frequency', sprintf('%g', params.frequency));
                set_param([model_name '/' cid], 'Phase', sprintf('%g', params.phase_degrees));
                conn1 = conn.positive;
                conn2 = conn.negative;
                node_blocks = append_node(node_blocks, conn1, struct('block', cid, 'port', 1));
                node_blocks = append_node(node_blocks, conn2, struct('block', cid, 'port', 2));

            case 'VoltageSourceDC'
                add_block(lib.dc_voltage, [model_name '/' cid]);
                set_param([model_name '/' cid], 'Position', pos);
                set_param([model_name '/' cid], 'Amplitude', num2str(params.voltage));
                conn1 = conn.positive;
                conn2 = conn.negative;
                node_blocks = append_node(node_blocks, conn1, struct('block', cid, 'port', 1));
                node_blocks = append_node(node_blocks, conn2, struct('block', cid, 'port', 2));

            case 'Inductor'
                add_block(lib.series_rlc, [model_name '/' cid]);
                set_param([model_name '/' cid], 'Position', pos);
                set_param([model_name '/' cid], 'BranchType', 'L');
                set_param([model_name '/' cid], 'Inductance', num2str(params.inductance));
                conn1 = conn.terminal_1;
                conn2 = conn.terminal_2;
                node_blocks = append_node(node_blocks, conn1, struct('block', cid, 'port', 1));
                node_blocks = append_node(node_blocks, conn2, struct('block', cid, 'port', 2));

            case 'Capacitor'
                add_block(lib.series_rlc, [model_name '/' cid]);
                set_param([model_name '/' cid], 'Position', pos);
                set_param([model_name '/' cid], 'BranchType', 'C');
                set_param([model_name '/' cid], 'Capacitance', num2str(params.capacitance));
                conn1 = conn.terminal_1;
                conn2 = conn.terminal_2;
                node_blocks = append_node(node_blocks, conn1, struct('block', cid, 'port', 1));
                node_blocks = append_node(node_blocks, conn2, struct('block', cid, 'port', 2));

            otherwise
                warning('Unsupported component type: %s', ctype);
        end
    end

    % Add Voltage Sensor to measure first non-GND node (e.g. s1)
    measure_node = '';
    for i = 1:length(nodes)
        if ~strcmp(nodes{i}, 'GND')
            measure_node = nodes{i};
            break;
        end
    end

    if ~isempty(measure_node)
        % SPS Voltage Measurement: + and - ports, outputs Simulink signal directly
        add_block(lib.voltage_meas, [model_name '/VoltageMeasurement']);
        set_param([model_name '/VoltageMeasurement'], 'Position', [400 150 450 200]);
        add_block('simulink/Sinks/To Workspace', [model_name '/ToWorkspace']);
        set_param([model_name '/ToWorkspace'], 'VariableName', 'voltage_out');
        set_param([model_name '/ToWorkspace'], 'SaveFormat', 'Structure With Time');
        set_param([model_name '/ToWorkspace'], 'Position', [500 150 550 200]);

        % Connect Voltage Measurement: + to measure_node, - to GND
        vs_plus = struct('block', 'VoltageMeasurement', 'port', 1);
        vs_minus = struct('block', 'VoltageMeasurement', 'port', 2);
        node_blocks = append_node(node_blocks, measure_node, vs_plus);
        node_blocks = append_node(node_blocks, 'GND', vs_minus);

        % Connect Voltage Measurement output to To Workspace
        add_line(model_name, [model_name '/VoltageMeasurement/1'], [model_name '/ToWorkspace/1'], 'autorouting', 'on');
    end

    % Connect components at each node (except GND which uses Reference)
    for i = 1:length(nodes)
        n = nodes{i};
        list = node_blocks(n);
        if isempty(list), continue; end

        if strcmp(n, 'GND')
            % Connect each block's port to GND block (list is cell array)
            for j = 1:length(list)
                b = list{j};
                add_line(model_name, [model_name '/' b.block '/' num2str(b.port)], ...
                    [model_name '/GND/1'], 'autorouting', 'on');
            end
        else
            % Connect all blocks at this node in a chain
            for j = 1:length(list)-1
                b1 = list{j};
                b2 = list{j+1};
                add_line(model_name, [model_name '/' b1.block '/' num2str(b1.port)], ...
                    [model_name '/' b2.block '/' num2str(b2.port)], 'autorouting', 'on');
            end
        end
    end

    % Set solver to fixed-step to match EMTP
    set_param(model_name, 'Solver', 'ode14x');
    set_param(model_name, 'SolverType', 'Fixed-step');
    set_param(model_name, 'FixedStep', num2str(solver.step_size));
    set_param(model_name, 'StopTime', num2str(solver.stop_time));

    % Save model
    model_path = fullfile(fileparts(json_path), [model_name '.slx']);
    save_system(model_name, model_path);

    % Run simulation (To Workspace writes to base workspace)
    sim(model_name);

    % Export to CSV - get data from base workspace
    csv_path = fullfile(fileparts(json_path), [model_name '_simscape.csv']);
    try
        d = evalin('base', 'voltage_out');
        t = d.time;
        v = d.signals.values;
    catch
        error('Could not retrieve simulation output. Ensure Voltage Sensor and To Workspace are connected.');
    end

    fid = fopen(csv_path, 'w');
    fprintf(fid, 'Time (s);Voltage (V);\n');
    for i = 1:length(t)
        fprintf(fid, '%.6e;%.10e;\n', t(i), v(i));
    end
    fclose(fid);

    fprintf('Model saved: %s\n', model_path);
    fprintf('Simulation results: %s\n', csv_path);

    function m = append_node(m, node_name, item)
        % Append item to cell array stored in Map (MATLAB doesn't allow m(key){end+1}=x)
        list = m(node_name);
        list{end+1} = item;
        m(node_name) = list;
    end
end
