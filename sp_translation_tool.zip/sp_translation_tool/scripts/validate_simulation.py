#!/usr/bin/env python3
"""
Validate that Simscape simulation results match EMTP results.
Compares voltage waveforms using RMSE after interpolating onto a common time vector.

Usage:
  python validate_simulation.py [circuit_dir]
  python validate_simulation.py data/EMTP/Circ_AC_R_1

Expects:
  - res150301.csv (or similar) - EMTP results
  - Circuit150301_simscape.csv - Simscape results (from json_to_simscape.m)
"""

import argparse
import sys
from pathlib import Path

import numpy as np


def load_emtp_csv(csv_path: Path) -> tuple[np.ndarray, np.ndarray]:
    """Load EMTP CSV: time (s), voltage (V). Format: time;voltage with scientific notation."""
    lines = csv_path.read_text(encoding="utf-8").strip().splitlines()
    # Skip header (first 3 lines typically)
    data_lines = []
    for line in lines:
        line = line.strip()
        if not line or line.startswith("X axis") or line.startswith("Time ("):
            continue
        parts = line.split(";")
        if len(parts) >= 2:
            try:
                t = float(parts[0])
                v = float(parts[1])
                data_lines.append((t, v))
            except ValueError:
                continue
    if not data_lines:
        raise ValueError(f"No data parsed from {csv_path}")
    t = np.array([x[0] for x in data_lines])
    v = np.array([x[1] for x in data_lines])
    return t, v


def load_simscape_csv(csv_path: Path) -> tuple[np.ndarray, np.ndarray]:
    """Load Simscape CSV: Time (s);Voltage (V)."""
    lines = csv_path.read_text(encoding="utf-8").strip().splitlines()
    data_lines = []
    for line in lines:
        line = line.strip()
        if not line or "Time" in line and "Voltage" in line:
            continue
        parts = line.split(";")
        if len(parts) >= 2:
            try:
                t = float(parts[0])
                v = float(parts[1])
                data_lines.append((t, v))
            except ValueError:
                continue
    if not data_lines:
        raise ValueError(f"No data parsed from {csv_path}")
    t = np.array([x[0] for x in data_lines])
    v = np.array([x[1] for x in data_lines])
    return t, v


def compute_rmse(
    t_emtp: np.ndarray,
    v_emtp: np.ndarray,
    t_simscape: np.ndarray,
    v_simscape: np.ndarray,
) -> float:
    """
    Interpolate Simscape onto EMTP time vector and compute RMSE.
    EMTP uses fixed step; Simscape may use variable step.
    """
    if len(t_simscape) < 2:
        raise ValueError("Simscape data has too few points")
    v_flat = np.ravel(v_simscape)
    v_simscape_interp = np.interp(
        t_emtp,
        t_simscape,
        v_flat,
        left=v_flat[0],
        right=v_flat[-1],
    )
    rmse = np.sqrt(np.mean((v_emtp - v_simscape_interp) ** 2))
    return float(rmse)


def main():
    parser = argparse.ArgumentParser(description="Validate Simscape vs EMTP simulation results")
    parser.add_argument(
        "circuit_dir",
        nargs="?",
        default=Path(__file__).parent.parent / "data/EMTP/Circ_AC_R_1",
        type=Path,
        help="Directory containing EMTP and Simscape CSV results",
    )
    parser.add_argument(
        "--emtp",
        type=Path,
        help="EMTP CSV path (default: circuit_dir/res150301.csv)",
    )
    parser.add_argument(
        "--simscape",
        type=Path,
        help="Simscape CSV path (default: circuit_dir/Circuit150301_simscape.csv)",
    )
    parser.add_argument(
        "--tolerance",
        type=float,
        default=1e-2,
        help="RMSE tolerance in Volts (default: 0.01)",
    )
    args = parser.parse_args()

    circuit_dir = Path(args.circuit_dir)
    emtp_path = args.emtp or circuit_dir / "res150301.csv"
    simscape_path = args.simscape or circuit_dir / "Circuit150301_simscape.csv"

    if not emtp_path.exists():
        print(f"Error: EMTP CSV not found: {emtp_path}", file=sys.stderr)
        print("Run EMTP simulation and export results to CSV.", file=sys.stderr)
        sys.exit(1)

    if not simscape_path.exists():
        print(f"Error: Simscape CSV not found: {simscape_path}", file=sys.stderr)
        print("Run json_to_simscape.m in MATLAB first.", file=sys.stderr)
        sys.exit(1)

    print(f"Loading EMTP: {emtp_path}")
    t_emtp, v_emtp = load_emtp_csv(emtp_path)
    print(f"  Points: {len(t_emtp)}, t=[{t_emtp[0]:.2e}, {t_emtp[-1]:.2e}] s")

    print(f"Loading Simscape: {simscape_path}")
    t_ss, v_ss = load_simscape_csv(simscape_path)
    print(f"  Points: {len(t_ss)}, t=[{t_ss[0]:.2e}, {t_ss[-1]:.2e}] s")

    rmse = compute_rmse(t_emtp, v_emtp, t_ss, v_ss)
    print(f"\nRMSE = {rmse:.6e} V")
    print(f"Tolerance = {args.tolerance} V")

    if rmse < args.tolerance:
        print("\nPASS: Simulation results match within tolerance.")
        sys.exit(0)
    else:
        print("\nFAIL: RMSE exceeds tolerance.")
        sys.exit(1)


if __name__ == "__main__":
    main()
