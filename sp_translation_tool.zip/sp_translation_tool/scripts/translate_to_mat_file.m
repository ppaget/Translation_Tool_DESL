%+ called from find_data_contents
% Used for files
% mymfilename is the full mfile name
% filename is the full name of binary file
% fidbin is the handle to the bin file opened from the calling function
% ncols is the number of columns of valid data in the binary file
% precision is the data precision
% fileformat: fortran when using a fortran generated binary file
function [nlines,mat_file_name]=...
translate_to_mat_file(mymfilename,filename,fidbin, ncols, precision,fileformat)

global DatafromFile        %the data from file option, contains all information on the file

%+ The mat file is NOT destroyed at the end if MPLOT completes
%  with no crash
[PATHSTR,NAME] = fileparts(filename);

if DatafromFile.active
   UseWaitbar=DatafromFile.Waitbar;
else
   UseWaitbar=1;
end

if UseWaitbar
    hwait=waitbar(0,'');
    set(hwait,'tag','mplot.waitbar');
    set(hwait,'windowstyle','modal');
    texts=findobj(findall(hwait),'type','text');
    set(texts,'interpreter','none');
    waitbar(0,hwait,['Loading binary data file'  ]); %NAME can exceed the size of the window
end

%%Generate the mat_file_name including the path-----------------------------------------------------------------------------------
[PATHSTR,NAME] = fileparts(mymfilename);
if( length(PATHSTR) ~= 0 )
    PATHSTR = [PATHSTR '\'];
else
    %this is when the user starts the file with no path from MATLAB and then changes the directory
    PATHSTR = [pwd '\'];
end
% Random style mat file or fixed name when using DatafromFile.active
if DatafromFile.use_mat_extension
  mat_file_name= [ PATHSTR  NAME  '.mat' ];
else
  mat_file_name= [ PATHSTR  NAME '_' datestr(datenum(clock),30) '.mat' ];
end
%%--------------------------------------------------------------------------------------------------------------------------------
%
%
%
%+detect the type of format, fortran data file or ordinary
form=strcmp(fileformat,'fortran');

%+find the number of bytes in this files
fseek(fidbin,0,'eof'); nlines=ftell(fidbin); %the number of bytes is given by nlines

%+find the number of lines by dividing the number of bytes by the number of bytes per line
if strcmp(precision,'float32')
    %single precision file, everything is 4 bytes, all collumns are 4 bytes
    %there is an extra data of 4 bytes at the start of each row and at the end of each row when fortran
    % that is why there is a total of ncols+2 per line
    nlines=nlines/((ncols+2*form)*4);   %number of lines in this file, 4 bytes by data
elseif strcmp(precision,'float64')
    %double precision file, all data is 8 bytes
    %there is an extra data of 4 bytes at the start of each row and at the end of each row when fortran
    % that is why there is a total of 2*4 extra per line
    nlines=nlines/(ncols*8+2*form*4);   %number of lines in this file
end

fseek(fidbin,0,'bof');                     %go back to first record of file

if UseWaitbar
 waitbar(.5,hwait);
end

%+Skip the first byte when fortran
if form==1
  fread(fidbin,1,'float32'); %skip the first read when fortran file, it is always 4 bytes
end

%+Read the correct number of data and save it into the matrix
% check if the mat file was created after the bin file
do_reload=1;
if  exist(mat_file_name) > 0
   d=dir(filename); %the date of the bin file
   binfile_date=d.date;

   d=dir(mat_file_name);
   if datenum(d.date) > datenum(binfile_date)
      %mat_file has been created after binary file so do not reload
      do_reload=0;
   end
end


if do_reload==1
    nvalues=nlines*ncols;
    p=[num2str(ncols) '*' precision]; %read ncols values per line and skip the uselesess data at the end
    %%READ binary file
    amatrix=fread(fidbin,nvalues,p,2*form*4);
    %
    if UseWaitbar
       waitbar(.90,hwait);
    end

    %+SAVE INTO MAT FILE
    save( mat_file_name ,'amatrix');
end


if UseWaitbar
    waitbar(100,hwait);
    close(hwait);
end

fclose(fidbin);
