# EMTP–Simscape Circuit Translation Tool

Bidirectional converter between EMTP (electromagnetic transient) and Simscape Electrical. Uses a JSON intermediate format as the single source of truth. See [Plan_Idea.md](Plan_Idea.md) for architecture and motivation.

---

## EMTP to JSON (Working)

### Overview

The EMTP pipeline parses circuit files and produces a standardized JSON description:

- **Topology:** nodes, components, connections
- **Parameters:** resistance, voltage, frequency, etc. (SI units)
- **Solver settings:** step size, stop time
- **Layout:** optional coordinates from DXF for Simscape placement

### Data Sources

| File | Content |
|------|---------|
| `.net` | Netlist: topology, parameters, solver (primary source) |
| `.dxf` | Layout coordinates for components |

The `.ecf` file is proprietary binary and is not parsed. EMTPWorks generates `.net` and `.dxf` from the schematic.

### Usage

Run from the project root:

**Full pipeline** (net + DXF → JSON with coordinates):

```bash
python parsers/emtp_to_json.py data/EMTP/Circ_AC_R_1
```

**Options:**

| Option | Description |
|--------|-------------|
| `circuit_dir` | Directory with `*.net` and `*.dxf` (default: `data/EMTP/Circ_AC_R_1`) |
| `--no-dxf` | Skip DXF parsing; output has no `position` fields |
| `--validate` | Validate output against `schemas/circuit_schema.json` |

**Examples:**

```bash
# Default circuit
python parsers/emtp_to_json.py

# Custom directory
python parsers/emtp_to_json.py path/to/my/circuit

# Topology only (no coordinates)
python parsers/emtp_to_json.py data/EMTP/Circ_AC_R_1 --no-dxf

# With schema validation
python parsers/emtp_to_json.py data/EMTP/Circ_AC_R_1 --validate
```

### Output

Writes `{circuit_name}.json` in the same directory as the `.net` file:

```json
{
  "schema_version": "1.0",
  "model_name": "Circuit150301",
  "solver_settings": { "stop_time": 0.032, "step_size": 1e-06 },
  "nodes": ["GND", "s1"],
  "components": [
    {
      "id": "R1",
      "type": "Resistor",
      "parameters": { "resistance": 1.0 },
      "connections": { "terminal_1": "s1", "terminal_2": "GND" },
      "position": { "x": 2.847, "y": 4.528 }
    },
    ...
  ]
}
```

### Supported Components

| EMTP type | JSON type | Parameters |
|-----------|-----------|------------|
| `_RLC` (R only) | Resistor | `resistance` |
| `_RLC` (L only) | Inductor | `inductance` |
| `_RLC` (C only) | Capacitor | `capacitance`, `initial_voltage` |
| `_Vsine` | VoltageSourceAC | `voltage_rms`, `frequency`, `phase_degrees` |
| `_Vdc` | VoltageSourceDC | `voltage` |

### Project structure

```
parsers/
├── emtp_net_parser.py   # .net → topology, params, solver
├── emtp_dxf_parser.py   # .dxf → coordinates
└── emtp_to_json.py      # Main pipeline

schemas/
└── circuit_schema.json  # JSON schema

data/EMTP/Circ_AC_R_1/
├── Circuit150301.net
├── Circuit150301.dxf
├── Circuit150301.json   # Generated
└── res150301.csv        # EMTP simulation results (for validation)
```

### Dependencies

```bash
pip install -r requirements.txt
```

Optional: `jsonschema` for `--validate`.

---

## JSON to Simscape (In Progress)

### Current state

`scripts/json_to_simscape.m` is a MATLAB script that:

- Reads the circuit JSON
- Builds a Simscape Electrical model using **Specialized Power Systems** (SPS) blocks
- Adds powergui, Ground, Resistor, AC/DC sources, Voltage Measurement
- Connects components according to node topology
- Sets fixed-step solver (same as EMTP)
- Runs the simulation and exports to CSV

### What is implemented

- Block library mapping (`spsXxxLib/Block Name` format)
- Component types: Resistor, Inductor, Capacitor, VoltageSourceAC, VoltageSourceDC
- Node connection logic (chaining at nodes, GND connections)
- Voltage Measurement + To Workspace for CSV export
- Solver configuration (step size, stop time)

### Known issues

- **Block paths:** Some paths may differ by MATLAB version (e.g. powergui, Voltage Measurement). Use `get_param(gcb, 'ReferenceBlock')` on a manually placed block to get the correct path.
- **Simulation:** The script may still fail during simulation or connection. Debugging is ongoing.
- **Validation:** `validate_simulation.py` expects both EMTP and Simscape CSV results; Simscape CSV is not yet produced reliably.

### How to continue

1. **Fix block paths:** Run the script and, for each error, add the block manually, select it, run `get_param(gcb, 'ReferenceBlock')`, and update the `lib` struct in `json_to_simscape.m` (lines 41–47).

2. **Test connection logic:** If the model builds but connections fail, inspect `add_line` calls. Ensure full block paths are used (e.g. `Circuit150301/R1/2` instead of `R1/2`).

3. **Verify CSV export:** After a successful simulation, ensure `voltage_out` is in the base workspace and `To Workspace` writes correctly. Check `SaveFormat` and `VariableName`.

4. **Run validation:** Once Simscape CSV is produced, run:
   ```bash
   python scripts/validate_simulation.py data/EMTP/Circ_AC_R_1
   ```

### Prerequisites

- MATLAB R2024b or compatible
- Simulink
- Simscape Electrical (Specialized Power Systems)

### Usage (when working)

```matlab
addpath('scripts');
[json_path, csv_path] = json_to_simscape('data/EMTP/Circ_AC_R_1/Circuit150301.json');
```

---

## Validation

`scripts/validate_simulation.py` compares EMTP and Simscape voltage waveforms:

```bash
python scripts/validate_simulation.py data/EMTP/Circ_AC_R_1
```

- Loads `res150301.csv` (EMTP) and `Circuit150301_simscape.csv` (Simscape)
- Interpolates Simscape onto EMTP time vector
- Computes RMSE; pass if RMSE < tolerance (default 0.01 V)

Options: `--emtp`, `--simscape`, `--tolerance`.

---

## EMTP simulation results

EMTP can export results in two ways:

- **CSV** (`res150301.csv`): time;voltage pairs, human-readable
- **.mda** (binary): Fortran format, float64, 5 columns.

Use `scripts/translate_to_mat_file.m` and `scripts/read_function.m` to convert `.mda` to `.mat` for MATLAB.
