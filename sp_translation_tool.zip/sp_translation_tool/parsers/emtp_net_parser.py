#!/usr/bin/env python3
"""
Parse EMTP .net files into a standardized JSON circuit format.
Extracts topology, parameters, and solver settings.
"""

import json
import re
import sys
from pathlib import Path


def parse_time_value(s: str) -> float:
    """Parse EMTP time strings like '1us', '32ms' to seconds."""
    s = s.strip().lower()
    # Check longer suffixes first to avoid "us" matching "s"
    multipliers = [("ns", 1e-9), ("us", 1e-6), ("ms", 1e-3), ("s", 1)]
    for suffix, mult in multipliers:
        if s.endswith(suffix):
            try:
                return float(s[:-len(suffix)]) * mult
            except ValueError:
                return 0.0
    try:
        return float(s)
    except ValueError:
        return 0.0


def parse_voltage_value(s: str) -> float:
    """Parse EMTP voltage strings like '0.230kVRMS', '100V' to Volts (SI)."""
    s = s.strip().upper()
    # Check longer suffixes first
    multipliers = [("KVRMS", 1e3), ("VRMS", 1), ("MV", 1e6), ("KV", 1e3), ("V", 1)]
    for suffix, mult in multipliers:
        if s.endswith(suffix):
            try:
                return float(s[:-len(suffix)]) * mult
            except ValueError:
                pass
    try:
        return float(s)
    except ValueError:
        return 0.0


def parse_net_file(net_path: Path) -> dict:
    """
    Parse an EMTP .net file and return a circuit dict in the target JSON schema.
    """
    content = net_path.read_text(encoding="utf-8", errors="replace")
    lines = content.splitlines()

    # Extract model name from Circuit.Diagram or filename
    model_name = net_path.stem
    for line in lines:
        if "Circuit.Diagram=" in line:
            match = re.search(r"Circuit\.Diagram=([^;]+)", line)
            if match:
                model_name = Path(match.group(1).strip()).stem
            break

    # Default solver settings
    step_size = 1e-6
    stop_time = 0.1

    for line in lines:
        line = line.strip()
        if line.startswith("Dt="):
            step_size = parse_time_value(line[3:].rstrip(";"))
        elif line.startswith("tmax="):
            stop_time = parse_time_value(line[5:].rstrip(";"))

    nodes = ["GND"]  # GND is always present
    components = []
    i = 0

    while i < len(lines):
        line = lines[i].strip()
        # Component definition: _Type;Name;?;?;Node1,Node2,...
        if line.startswith("_"):
            parts = line.split(";")
            if len(parts) >= 5:
                emtp_type = parts[0].strip()
                device_id = parts[1].strip()
                node_str = parts[4].strip()
                node_parts = [n.strip() for n in node_str.split(",") if n.strip()]

                # First node
                node1 = node_parts[0] if node_parts else "GND"
                node2 = "GND" if len(node_parts) < 2 or not node_parts[1] else node_parts[1]

                for n in [node1, node2]:
                    if n and n != "GND" and n not in nodes:
                        nodes.append(n)

                # Get data line (next non-empty, non-comment line)
                data_line = ""
                j = i + 1
                while j < len(lines):
                    next_line = lines[j].strip()
                    if next_line and not next_line.startswith("!"):
                        data_line = next_line
                        break
                    j += 1

                comp = _parse_component(emtp_type, device_id, node1, node2, data_line)
                if comp:
                    components.append(comp)

        i += 1

    # Ensure GND is first in nodes list
    if "GND" in nodes:
        nodes.remove("GND")
    nodes.insert(0, "GND")

    return {
        "schema_version": "1.0",
        "model_name": model_name,
        "solver_settings": {
            "stop_time": stop_time,
            "step_size": step_size,
        },
        "nodes": nodes,
        "components": components,
    }


def _parse_component(
    emtp_type: str, device_id: str, node1: str, node2: str, data_line: str
) -> dict | None:
    """Parse a single component from EMTP type and data line."""
    data_parts = [p.strip() for p in data_line.split(",")] if data_line else []

    if emtp_type == "_RLC":
        return _parse_rlc(device_id, node1, node2, data_parts)
    elif emtp_type == "_Vsine":
        return _parse_vsine(device_id, node1, node2, data_parts)
    elif emtp_type == "_Vdc":
        return _parse_vdc(device_id, node1, node2, data_parts)
    return None


def _parse_rlc(
    device_id: str, node1: str, node2: str, data_parts: list
) -> dict | None:
    """Parse RLC branch. Data: R,L,C,..."""
    if len(data_parts) < 3:
        return None
    try:
        r = float(data_parts[0]) if data_parts[0] else 0
        l_val = float(data_parts[1]) if data_parts[1] else 0
        c = float(data_parts[2]) if data_parts[2] else 0
    except ValueError:
        return None

    if r > 0 and l_val == 0 and c == 0:
        return {
            "id": device_id,
            "type": "Resistor",
            "parameters": {"resistance": r},
            "connections": {"terminal_1": node1, "terminal_2": node2},
        }
    elif l_val > 0 and r == 0 and c == 0:
        return {
            "id": device_id,
            "type": "Inductor",
            "parameters": {"inductance": l_val},
            "connections": {"terminal_1": node1, "terminal_2": node2},
        }
    elif c > 0 and r == 0 and l_val == 0:
        return {
            "id": device_id,
            "type": "Capacitor",
            "parameters": {"capacitance": c, "initial_voltage": 0.0},
            "connections": {"terminal_1": node1, "terminal_2": node2},
        }
    # Generic RLC - treat as resistor if R present
    elif r > 0:
        return {
            "id": device_id,
            "type": "Resistor",
            "parameters": {"resistance": r},
            "connections": {"terminal_1": node1, "terminal_2": node2},
        }
    return None


def _parse_vsine(
    device_id: str, node1: str, node2: str, data_parts: list
) -> dict:
    """Parse AC voltage source. Data: Vrms,freq,phase,..."""
    voltage_rms = 0.0
    frequency = 60.0
    phase_degrees = 0.0
    if len(data_parts) >= 1 and data_parts[0]:
        voltage_rms = parse_voltage_value(data_parts[0])
    if len(data_parts) >= 2 and data_parts[1]:
        try:
            frequency = float(data_parts[1])
        except ValueError:
            pass
    if len(data_parts) >= 3 and data_parts[2]:
        try:
            phase_degrees = float(data_parts[2])
        except ValueError:
            pass

    return {
        "id": device_id,
        "type": "VoltageSourceAC",
        "parameters": {
            "voltage_rms": voltage_rms,
            "frequency": frequency,
            "phase_degrees": phase_degrees,
        },
        "connections": {"positive": node1, "negative": node2},
    }


def _parse_vdc(
    device_id: str, node1: str, node2: str, data_parts: list
) -> dict:
    """Parse DC voltage source."""
    voltage = 0.0
    if len(data_parts) >= 1 and data_parts[0]:
        voltage = parse_voltage_value(data_parts[0])
    return {
        "id": device_id,
        "type": "VoltageSourceDC",
        "parameters": {"voltage": voltage},
        "connections": {"positive": node1, "negative": node2},
    }


def main():
    if len(sys.argv) < 2:
        net_path = Path(__file__).parent.parent / "data/EMTP/Circ_AC_R_1/Circuit150301.net"
    else:
        net_path = Path(sys.argv[1])

    if not net_path.exists():
        print(f"Error: File not found: {net_path}", file=sys.stderr)
        sys.exit(1)

    circuit = parse_net_file(net_path)
    out_path = net_path.parent / f"{net_path.stem}.json"
    out_path.write_text(json.dumps(circuit, indent=2), encoding="utf-8")
    print(f"Wrote {out_path}")


if __name__ == "__main__":
    main()
