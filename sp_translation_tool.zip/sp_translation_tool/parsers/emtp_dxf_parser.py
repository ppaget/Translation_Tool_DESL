#!/usr/bin/env python3
"""
Parse EMTP DXF files to extract component positions.
Associates INSERT entity coordinates with component names from TEXT entities.
"""

import json
import re
import sys
from pathlib import Path


def _looks_like_component_id(text: str, component_ids: list[str] | None) -> bool:
    """Check if text looks like a component ID."""
    if not text or text in ("?vi", "?v", "?i", "GND"):
        return False
    if component_ids:
        return text in component_ids
    # Heuristic: R1, AC1, C1, L1 - starts with letter, rest alphanumeric
    return bool(re.match(r"^[A-Za-z][A-Za-z0-9]*$", text))


def _pick_component_id(seen_texts: list[str], component_ids: list[str] | None) -> str | None:
    """From TEXT values near an INSERT, pick the component ID."""
    for t in reversed(seen_texts):  # Often the name is last
        if _looks_like_component_id(t, component_ids):
            return t
    return None


def parse_dxf_positions_v2(dxf_path: Path, component_ids: list[str] | None = None) -> dict[str, dict]:
    """
    Alternative implementation: iterate entities in order, associate INSERT with following TEXT.
    """
    content = dxf_path.read_text(encoding="utf-8", errors="replace")
    lines = content.splitlines()

    def iter_pairs():
        i = 0
        while i < len(lines) - 1:
            try:
                code = int(lines[i].strip())
                value = lines[i + 1].strip()
                yield code, value
                i += 2
            except (ValueError, IndexError):
                i += 1

    positions: dict[str, dict] = {}
    entities: list[dict] = []
    current: dict | None = None

    for code, value in iter_pairs():
        if code == 0:
            if current:
                entities.append(current)
            entity_type = value.upper()
            current = {"type": entity_type, "x": None, "y": None, "text": None}
        elif current is not None:
            if code == 10:
                try:
                    current["x"] = float(value)
                except ValueError:
                    pass
            elif code == 20:
                try:
                    current["y"] = float(value)
                except ValueError:
                    pass
            elif code == 1:
                current["text"] = value.strip()
    if current:
        entities.append(current)

    # Group: each INSERT is followed by TEXT entities. Find TEXT with component ID.
    i = 0
    while i < len(entities):
        e = entities[i]
        if e["type"] == "INSERT" and e["x"] is not None and e["y"] is not None:
            # Look at following entities until next INSERT for component name
            j = i + 1
            comp_id = None
            while j < len(entities):
                next_e = entities[j]
                if next_e["type"] == "INSERT":
                    break
                if next_e["type"] == "TEXT" and next_e.get("text"):
                    t = next_e["text"]
                    if _looks_like_component_id(t, component_ids):
                        comp_id = t
                j += 1
            if comp_id:
                positions[comp_id] = {"x": round(e["x"], 6), "y": round(e["y"], 6)}
        i += 1

    return positions


def merge_positions_into_circuit(circuit: dict, positions: dict[str, dict]) -> dict:
    """Add position to each component in the circuit dict. Modifies in place, returns circuit."""
    for comp in circuit.get("components", []):
        cid = comp.get("id")
        if cid and cid in positions:
            comp["position"] = positions[cid]
    return circuit


def main():
    if len(sys.argv) < 2:
        base = Path(__file__).parent.parent / "data/EMTP/Circ_AC_R_1"
        dxf_path = base / "Circuit150301.dxf"
        json_path = base / "Circuit150301.json"
    else:
        dxf_path = Path(sys.argv[1])
        json_path = dxf_path.parent / f"{dxf_path.stem}.json" if len(sys.argv) < 3 else Path(sys.argv[2])

    if not dxf_path.exists():
        print(f"Error: DXF not found: {dxf_path}", file=sys.stderr)
        sys.exit(1)

    # Load existing JSON if present to get component IDs
    component_ids = None
    if json_path.exists():
        circuit = json.loads(json_path.read_text(encoding="utf-8"))
        component_ids = [c["id"] for c in circuit.get("components", [])]
    else:
        circuit = {"components": []}

    positions = parse_dxf_positions_v2(dxf_path, component_ids)
    circuit = merge_positions_into_circuit(circuit, positions)

    json_path.write_text(json.dumps(circuit, indent=2), encoding="utf-8")
    print(f"Updated {json_path} with positions for: {list(positions.keys())}")


if __name__ == "__main__":
    main()
