#!/usr/bin/env python3
"""
Full pipeline: Parse EMTP .net + .dxf files into a standardized JSON circuit format.
Usage: python emtp_to_json.py [circuit_dir] [--no-dxf]
  circuit_dir: directory containing CircuitName.net and CircuitName.dxf (default: data/EMTP/Circ_AC_R_1)
  --no-dxf: skip DXF parsing (no coordinates in output)
"""

import argparse
import json
import sys
from pathlib import Path

# Add parent for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

from parsers.emtp_net_parser import parse_net_file
from parsers.emtp_dxf_parser import parse_dxf_positions_v2, merge_positions_into_circuit


def validate_with_schema(circuit: dict, schema_path: Path) -> bool:
    """Validate circuit against JSON schema if jsonschema is available."""
    try:
        import jsonschema
        schema = json.loads(schema_path.read_text(encoding="utf-8"))
        jsonschema.validate(circuit, schema)
        return True
    except ImportError:
        return True  # Skip if jsonschema not installed
    except Exception as e:
        print(f"Schema validation warning: {e}", file=sys.stderr)
        return False


def main():
    parser = argparse.ArgumentParser(description="Convert EMTP circuit to JSON")
    parser.add_argument(
        "circuit_dir",
        nargs="?",
        default=Path(__file__).parent.parent / "data/EMTP/Circ_AC_R_1",
        type=Path,
        help="Directory containing .net and .dxf files",
    )
    parser.add_argument("--no-dxf", action="store_true", help="Skip DXF parsing (no coordinates)")
    parser.add_argument("--validate", action="store_true", help="Validate output against schema")
    args = parser.parse_args()

    circuit_dir = Path(args.circuit_dir)
    if not circuit_dir.is_dir():
        print(f"Error: Not a directory: {circuit_dir}", file=sys.stderr)
        sys.exit(1)

    # Find .net file
    net_files = list(circuit_dir.glob("*.net"))
    if not net_files:
        print(f"Error: No .net file found in {circuit_dir}", file=sys.stderr)
        sys.exit(1)

    net_path = net_files[0]
    stem = net_path.stem
    dxf_path = circuit_dir / f"{stem}.dxf"
    json_path = circuit_dir / f"{stem}.json"

    # Step 1: Parse .net
    print(f"Parsing {net_path}...")
    circuit = parse_net_file(net_path)

    # Step 2: Parse .dxf and merge positions
    if not args.no_dxf and dxf_path.exists():
        print(f"Parsing {dxf_path} for coordinates...")
        component_ids = [c["id"] for c in circuit.get("components", [])]
        positions = parse_dxf_positions_v2(dxf_path, component_ids)
        circuit = merge_positions_into_circuit(circuit, positions)
        print(f"  Added positions for: {list(positions.keys())}")
    elif args.no_dxf:
        print("Skipping DXF (--no-dxf)")
    else:
        print(f"No DXF found at {dxf_path}, skipping coordinates")

    # Write output
    json_path.write_text(json.dumps(circuit, indent=2), encoding="utf-8")
    print(f"Wrote {json_path}")

    # Optional validation
    if args.validate:
        schema_path = Path(__file__).parent.parent / "schemas/circuit_schema.json"
        if schema_path.exists():
            if validate_with_schema(circuit, schema_path):
                print("Schema validation: OK")
            else:
                print("Schema validation: FAILED", file=sys.stderr)
        else:
            print(f"Schema not found: {schema_path}", file=sys.stderr)


if __name__ == "__main__":
    main()
